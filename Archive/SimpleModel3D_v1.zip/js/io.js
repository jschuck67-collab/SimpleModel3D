import * as THREE from 'three';
import { STLExporter } from 'three/addons/exporters/STLExporter.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';

export function saveProject(objects) {
    const name = document.getElementById('project-name').value || "project";
    const data = { objects: objects.map(o => o.toJSON()) };
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: "application/json" }));
    link.download = `${name}.json`; 
    link.click();
}

export function exportGLB(objects) {
    const name = document.getElementById('project-name').value || "model";
    const exporter = new GLTFExporter();
    const exportScene = new THREE.Scene();
    objects.forEach(obj => {
        const clone = obj.clone();
        clone.applyMatrix4(obj.matrixWorld);
        exportScene.add(clone);
    });
    exporter.parse(exportScene, function(glb) {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(new Blob([glb], { type: 'application/octet-stream' }));
        link.download = `${name}.glb`;
        link.click();
    }, function(err) { console.error(err); }, { binary: true });
}

export function exportSTL(objects) { 
    const name = document.getElementById('project-name').value || "model";
    const exporter = new STLExporter(); 
    const exportScene = new THREE.Scene(); 
    objects.forEach(obj => { 
        const clone = obj.clone(); 
        clone.applyMatrix4(obj.matrixWorld); 
        exportScene.add(clone); 
    }); 
    const res = exporter.parse(exportScene); 
    const link = document.createElement('a'); 
    link.href = URL.createObjectURL(new Blob([res], { type: 'text/plain' })); 
    link.download = `${name}.stl`; 
    link.click(); 
}