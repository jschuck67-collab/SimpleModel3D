import * as THREE from 'three';
import { Brush, Evaluator, SUBTRACTION, ADDITION, INTERSECTION } from 'three-bvh-csg';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';
import { ViewHelper } from 'three/addons/helpers/ViewHelper.js';
import { SVGLoader } from 'three/addons/loaders/SVGLoader.js';
import { initScene } from './sceneSetup.js';
import { toDeg, toRad, formatVal, toDisplay, fromDisplay, generateRandomColor, getLocalSize } from './utils.js';
import { saveProject, exportSTL, exportGLB } from './io.js';

let scene, camera, renderer, orbit, transform, rulerGroup;
let raycaster = new THREE.Raycaster();
let mouse = new THREE.Vector2();
let pointerDownPosition = new THREE.Vector2();
let objects = []; 
let selection = []; 
let selectionHelpers = [];
let undoStack = [];
let redoStack = [];
let clipboard = [];

let isMarquee = false;
let marqueeStart = new THREE.Vector2();
let marqueeElem;

let perspCamera, orthoCamera, isOrtho = false;
let viewHelper, clock;
let isBuildPlate = false;
let buildPlate;
// RULER VARS
let rulerActive = false;
let rulerPoints = [];
let dropSurfaceActive = false;
let isVertexSnapping = false;

let isWireframe = false;
let showDimensions = false;
let useRandomColors = false; 
let isLightMode = false;
let currentUnit = 'mm'; 
let isSnapping = false;

const csgEvaluator = new Evaluator();
let currentSpace = 'world';

window.createShape = createShape;
window.performBoolean = performBoolean;
window.mirrorSelected = mirrorSelected;
window.groupSelected = groupSelected;
window.alignObjects = alignObjects;
window.performArray = performArray;
window.handleDrop = handleDrop;
window.ungroupSelected = ungroupSelected;
window.cloneSelected = cloneSelected;
window.redo = redo;
window.setView = setView;
window.updateBuildPlate = updateBuildPlate;
window.updateObjectFromUI = updateObjectFromUI;
window.handleDropButton = handleDropButton;
window.toggleTheme = toggleTheme;
window.updateLighting = updateLighting;
window.toggleDimensions = toggleDimensions;
window.exportSTL = () => exportSTL(objects);
window.exportSelectedSTL = () => { if (selection.length > 0) exportSTL(selection); else alert('Select objects to export!'); };
window.exportGLB = () => exportGLB(objects);
window.exportSelectedGLB = () => { if (selection.length > 0) exportGLB(selection); else alert('Select objects to export!'); };
window.importSTL = () => document.getElementById('stl-input').click();
window.handleSTLImport = handleSTLImport;
window.handleSVGImport = handleSVGImport;
window.saveProject = () => saveProject(objects);
window.loadProject = loadProject;
window.newScene = newScene;
window.undo = undo;
window.handleRulerButton = handleRulerButton;
window.closeBevelModal = () => document.getElementById('bevel-modal').classList.add('hidden');
window.confirmBevelShape = confirmBevelShape;
window.closeTextModal = () => document.getElementById('text-modal').classList.add('hidden');
window.confirmTextShape = confirmTextShape;
window.setOrigin = setOrigin;
window.toggleCamera = toggleCamera;
window.snapToGrid = snapToGrid;
window.toggleVertexSnap = toggleVertexSnap;
window.dropToFloor = dropToFloor;
window.toggleSpace = toggleSpace;
window.togglePanel = (id) => document.getElementById(id).classList.toggle('minimized');

init();

function init() {
    const setup = initScene();
    scene = setup.scene;
    camera = setup.camera;
    perspCamera = setup.camera;
    camera = perspCamera;
    
    const aspect = window.innerWidth / window.innerHeight;
    const d = 20;
    // Use massive negative/positive near and far planes so Ortho never clips objects!
    orthoCamera = new THREE.OrthographicCamera(-d * aspect, d * aspect, d, -d, -10000, 10000);
    orthoCamera.position.copy(camera.position);
    orthoCamera.lookAt(0, 0, 0);

    renderer = setup.renderer;
    orbit = setup.orbit;
    transform = setup.transform;
    rulerGroup = setup.rulerGroup;
    
    renderer.autoClear = false;
    clock = new THREE.Clock();
    viewHelper = new ViewHelper(camera, renderer.domElement);
    viewHelper.center = orbit.target;

    // Virtual Build Plate (256x256x256mm Bambu P1S volume)
    const bpGeo = new THREE.BoxGeometry(256, 256, 256);
    const bpEdges = new THREE.EdgesGeometry(bpGeo);
    buildPlate = new THREE.LineSegments(bpEdges, new THREE.LineBasicMaterial({ color: 0x3498db, transparent: true, opacity: 0.5 }));
    // Offset Z by half the height so it sits perfectly on the floor grid
    buildPlate.position.set(0, 0, 128);
    buildPlate.visible = false;
    scene.add(buildPlate);

    const compassDiv = document.createElement('div');
    compassDiv.id = "compass-div";
    compassDiv.style.position = "absolute";
    compassDiv.style.bottom = "0";
    compassDiv.style.right = "0";
    compassDiv.style.width = "128px";
    compassDiv.style.height = "128px";
    compassDiv.style.zIndex = "100";
    document.body.appendChild(compassDiv);

    compassDiv.addEventListener('pointerdown', (e) => e.stopPropagation());
    compassDiv.addEventListener('pointerup', (e) => { e.stopPropagation(); viewHelper.handleClick(e); });

    transform.addEventListener('mouseDown', () => pushToUndo());
    transform.addEventListener('dragging-changed', (e) => orbit.enabled = !e.value);
    transform.addEventListener('change', () => { 
        // LIVE DRAG VERTEX SNAPPING 
        if (transform.dragging && transform.mode === 'translate' && isVertexSnapping && selection.length > 0) {
            raycaster.setFromCamera(mouse, camera);
            
            // Filter out currently selected objects so we don't snap to ourselves
            const targetObjects = objects.filter(o => {
                let isSelected = false;
                o.traverseAncestors(p => { if (selection.includes(p)) isSelected = true; });
                return !selection.includes(o) && !isSelected;
            });
            
            const intersects = raycaster.intersectObjects(targetObjects, true);
            if (intersects.length > 0) {
                const intersect = intersects[0];
                let targetVert = intersect.point;
                
                // Mathematically locate the closest physical vertex to the mouse on the target object
                if(intersect.object.geometry && intersect.face) {
                    const pos = intersect.object.geometry.attributes.position;
                    const wMat = intersect.object.matrixWorld;
                    const a = new THREE.Vector3().fromBufferAttribute(pos, intersect.face.a).applyMatrix4(wMat);
                    const b = new THREE.Vector3().fromBufferAttribute(pos, intersect.face.b).applyMatrix4(wMat);
                    const c = new THREE.Vector3().fromBufferAttribute(pos, intersect.face.c).applyMatrix4(wMat);
                    const dA = intersect.point.distanceTo(a);
                    const dB = intersect.point.distanceTo(b);
                    const dC = intersect.point.distanceTo(c);
                    if (dA <= dB && dA <= dC) targetVert = a;
                    else if (dB <= dA && dB <= dC) targetVert = b;
                    else targetVert = c;
                }
                
                // Find the closest vertex on our currently moving object to align them perfectly
                const movingObj = selection[selection.length - 1];
                let sourceVert = movingObj.position.clone();
                let minDist = Infinity;
                
                movingObj.updateMatrixWorld(true);
                movingObj.traverse(child => {
                    if (child.isMesh && child.geometry) {
                        const pos = child.geometry.attributes.position;
                        const wMat = child.matrixWorld;
                        for (let i = 0; i < pos.count; i++) {
                            const v = new THREE.Vector3().fromBufferAttribute(pos, i).applyMatrix4(wMat);
                            const dist = v.distanceTo(targetVert);
                            if (dist < minDist) {
                                minDist = dist;
                                sourceVert = v.clone();
                            }
                        }
                    }
                });
                
                // Magnetically snap the position only if we drag a corner within 5 units of the target!
                if (minDist < 5) {
                    const offset = targetVert.clone().sub(sourceVert);
                    selection.forEach(obj => {
                        obj.position.add(offset);
                        obj.updateMatrixWorld(true);
                    });
                }
            }
        }

        if(!transform.dragging) {
            if(selection.length > 0) updateInspectorUI(selection[selection.length - 1]); 
        }
    });

    marqueeElem = document.createElement('div');
    marqueeElem.className = 'marquee-box';
    document.body.appendChild(marqueeElem);

    window.addEventListener('pointerdown', (e) => {
        pointerDownPosition.set(e.clientX, e.clientY);
        if (e.shiftKey && e.button === 0 && !transform.dragging && !e.target.closest('.panel')) {
            isMarquee = true;
            orbit.enabled = false;
            marqueeStart.set(e.clientX, e.clientY);
            marqueeElem.style.left = e.clientX + 'px';
            marqueeElem.style.top = e.clientY + 'px';
            marqueeElem.style.width = '0px';
            marqueeElem.style.height = '0px';
            marqueeElem.style.display = 'block';
        }
    });
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('resize', onWindowResize);
    window.addEventListener('pointermove', (e) => {
        mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
        document.body.style.cursor = (rulerActive || dropSurfaceActive) ? 'crosshair' : (transform.axis ? 'pointer' : 'default');
        if (isMarquee) {
            const currentX = e.clientX;
            const currentY = e.clientY;
            marqueeElem.style.left = Math.min(marqueeStart.x, currentX) + 'px';
            marqueeElem.style.top = Math.min(marqueeStart.y, currentY) + 'px';
            marqueeElem.style.width = Math.abs(currentX - marqueeStart.x) + 'px';
            marqueeElem.style.height = Math.abs(currentY - marqueeStart.y) + 'px';
        }
    });

    document.getElementById('tool-move').addEventListener('click', () => setToolMode('translate'));
    document.getElementById('tool-rotate').addEventListener('click', () => setToolMode('rotate'));
    document.getElementById('tool-scale').addEventListener('click', () => setToolMode('scale'));
    document.getElementById('delete-btn').addEventListener('click', deleteObject);
    document.getElementById('wire-toggle').addEventListener('click', toggleWireframe);
    document.getElementById('build-plate-toggle').addEventListener('click', toggleBuildPlate);
    document.getElementById('snap-toggle').addEventListener('click', toggleSnap);
    document.getElementById('snap-val').addEventListener('change', updateSnapValue);
    document.getElementById('unit-mm').addEventListener('click', () => setUnit('mm'));
    document.getElementById('unit-in').addEventListener('click', () => setUnit('in'));
    document.getElementById('rand-color-toggle').addEventListener('click', toggleRandomColors);

    ['dimX', 'dimY', 'dimZ', 'posX','posY','posZ', 'rotX','rotY','rotZ'].forEach(id => {
        document.getElementById(id).addEventListener('input', updateObjectFromUI);
    });
    document.getElementById('objColor').addEventListener('input', updateObjectFromUI);
    document.getElementById('objOpacity').addEventListener('input', updateObjectFromUI);

    document.getElementById('objName').addEventListener('change', (e) => {
        if(selection.length > 0) {
            selection[selection.length - 1].name = e.target.value;
            updateOutliner();
        }
    });

    // --- AUTOSAVE / LOAD ON REFRESH ---
    window.addEventListener('beforeunload', () => {
        if (objects.length > 0) {
            const data = { objects: objects.map(o => o.toJSON()) };
            localStorage.setItem('jscad_autosave', JSON.stringify(data));
            localStorage.setItem('jscad_project_name', document.getElementById('project-name').value);
        } else {
            localStorage.removeItem('jscad_autosave');
            localStorage.removeItem('jscad_project_name');
        }
    });

    const savedData = localStorage.getItem('jscad_autosave');
    if (savedData) {
        try {
            const data = JSON.parse(savedData);
            const loader = new THREE.ObjectLoader();
            data.objects.forEach(json => {
                const o = loader.parse(json);
                    forceMaterialUpgrade(o);
                scene.add(o);
                objects.push(o);
                updateObjectVisuals(o);
            });
            const projName = localStorage.getItem('jscad_project_name');
            if (projName) document.getElementById('project-name').value = projName;
            setTimeout(() => document.getElementById('status-text').innerText = "Autosave recovered!", 500);
        } catch(e) { console.error('Error loading autosave:', e); }
    }

    updateOutliner();
    animate();
}

function updateBuildPlate(type) {
    let w = 256, d = 256, h = 256;
    if(type === 'ender3') { w = 220; d = 220; h = 250; }
    else if(type === 'prusa4') { w = 250; d = 210; h = 220; }
    else if(type === 'mini') { w = 180; d = 180; h = 180; }

    const isVisible = buildPlate.visible;
    scene.remove(buildPlate);
    buildPlate.geometry.dispose();
    buildPlate.material.dispose();

    const bpGeo = new THREE.BoxGeometry(w, d, h);
    const bpEdges = new THREE.EdgesGeometry(bpGeo);
    buildPlate = new THREE.LineSegments(bpEdges, new THREE.LineBasicMaterial({ color: 0x3498db, transparent: true, opacity: 0.5 }));
    buildPlate.position.set(0, 0, h / 2);
    buildPlate.visible = isVisible;
    scene.add(buildPlate);
}

// --- RULER LOGIC (ADAPTIVE & PERSISTENT) ---
function handleRulerButton() {
    const btn = document.getElementById('tool-ruler');
    const hasMeasurement = rulerPoints.length > 0;

    if (rulerActive) {
        // If currently measuring -> Deactivate, but keep measurement if exists
        rulerActive = false;
        btn.classList.remove('active-ruler-mode');
        document.getElementById('status-text').innerText = "Select objects...";
        if (hasMeasurement) btn.classList.add('active-ruler-visible'); // Green
    } else {
        // If not active
        if (hasMeasurement) {
            // If measurement exists -> Clear it
            clearRuler();
            btn.classList.remove('active-ruler-visible');
        } else {
            // Start Measuring
            rulerActive = true;
            deselectAll();
            btn.classList.add('active-ruler-mode');
            document.getElementById('status-text').innerText = "Ruler Mode: Click start point";
        }
    }
}

function clearRuler() {
    rulerPoints = [];
    rulerGroup.children.forEach(c => disposeHierarchy(c));
    rulerGroup.clear();
    document.getElementById('ruler-label').style.display = 'none';
    document.getElementById('tool-ruler').className = ''; // remove all classes
}

function handleRulerClick() {
    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObjects(objects, true);
    if (intersects.length > 0) {
        const intersect = intersects[0];
        const mesh = intersect.object;
        
        // SNAP TO VERTEX LOGIC
        let finalPoint = intersect.point;
        if(mesh.geometry && intersect.face) {
            const pos = mesh.geometry.attributes.position;
            const a = new THREE.Vector3().fromBufferAttribute(pos, intersect.face.a).applyMatrix4(mesh.matrixWorld);
            const b = new THREE.Vector3().fromBufferAttribute(pos, intersect.face.b).applyMatrix4(mesh.matrixWorld);
            const c = new THREE.Vector3().fromBufferAttribute(pos, intersect.face.c).applyMatrix4(mesh.matrixWorld);
            
            const distA = intersect.point.distanceTo(a);
            const distB = intersect.point.distanceTo(b);
            const distC = intersect.point.distanceTo(c);
            
            if(distA <= distB && distA <= distC) finalPoint = a;
            else if(distB <= distA && distB <= distC) finalPoint = b;
            else finalPoint = c;
        }

        // Adaptive Scale
        const box = new THREE.Box3().setFromObject(mesh);
        const sphere = new THREE.Sphere();
        box.getBoundingSphere(sphere);
        const markerScale = Math.max(0.05, sphere.radius * 0.03); 

        if (rulerPoints.length === 2) {
            // Starting a new measurement chain
            rulerPoints = [];
            rulerGroup.clear();
            document.getElementById('ruler-label').style.display = 'none';
        }

        rulerPoints.push(finalPoint);

        // Add Marker
        const markerGeo = new THREE.SphereGeometry(markerScale, 16, 16);
        const markerMat = new THREE.MeshBasicMaterial({ color: rulerPoints.length === 1 ? 0x00ff00 : 0xff0000, depthTest: false });
        const marker = new THREE.Mesh(markerGeo, markerMat);
        marker.position.copy(finalPoint);
        marker.renderOrder = 999;
        rulerGroup.add(marker);

        if (rulerPoints.length === 1) {
            document.getElementById('status-text').innerText = "Ruler: Click end point";
        } else if (rulerPoints.length === 2) {
            // Draw Line
            const points = rulerPoints;
            const geometry = new THREE.BufferGeometry().setFromPoints(points);
            const material = new THREE.LineBasicMaterial({ color: 0xffff00, depthTest: false, linewidth: 2 });
            const line = new THREE.Line(geometry, material);
            line.renderOrder = 998;
            rulerGroup.add(line);

            // Calc Distance
            const dist = rulerPoints[0].distanceTo(rulerPoints[1]);
            const displayDist = formatVal(dist, currentUnit) + (currentUnit === 'mm' ? ' mm' : ' in');
            document.getElementById('status-text').innerText = `Distance: ${displayDist}`;
            
            updateRulerLabel(); // Show label
        }
    }
}

function updateRulerLabel() {
    if (rulerPoints.length !== 2) return;
    const label = document.getElementById('ruler-label');
    const center = new THREE.Vector3().addVectors(rulerPoints[0], rulerPoints[1]).multiplyScalar(0.5);
    const dist = rulerPoints[0].distanceTo(rulerPoints[1]);
    
    label.innerText = formatVal(dist) + (currentUnit === 'mm' ? 'mm' : '"');
    
    // Project to screen
    center.project(camera);
    if (Math.abs(center.z) > 1) {
        label.style.display = 'none';
        return;
    }
    
    const x = (center.x * .5 + .5) * window.innerWidth;
    const y = (center.y * -.5 + .5) * window.innerHeight;
    
    label.style.display = 'block';
    label.style.left = `${x}px`;
    label.style.top = `${y}px`;
}

// --- DROP TO SURFACE LOGIC ---
function handleDropButton() {
    if (dropSurfaceActive) {
        dropSurfaceActive = false;
        document.getElementById('tool-drop').classList.remove('active-tool');
        document.getElementById('status-text').innerText = "Select objects...";
        if (selection.length > 0) transform.attach(selection[selection.length - 1]);
    } else {
        if (selection.length === 0) return alert("Select an object to drop first!");
        if (rulerActive) handleRulerButton(); // toggle ruler off
        
        transform.detach();
        dropSurfaceActive = true;
        document.getElementById('tool-drop').classList.add('active-tool');
        document.getElementById('status-text').innerText = "Face Snap: Click target surface";
    }
}

// --- FOCUS FEATURE ---
function frameSelected() {
    if (selection.length === 0) return;
    const box = new THREE.Box3();
    selection.forEach(obj => box.expandByObject(obj));
    if (box.isEmpty()) return;

    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    const fov = camera.fov * (Math.PI / 180);
    let cameraZ = Math.abs(maxDim / 2 / Math.tan(fov / 2));
    if (camera.aspect < 1) cameraZ = cameraZ / camera.aspect;
    
    cameraZ *= 2.5; 

    const direction = new THREE.Vector3().subVectors(camera.position, orbit.target).normalize();
    const newPos = center.clone().add(direction.multiplyScalar(cameraZ));

    camera.position.copy(newPos);
    camera.lookAt(center);
    orbit.target.copy(center);
        
        if (isOrtho) {
            const h = maxDim * 2.5;
            const aspect = window.innerWidth / window.innerHeight;
            orthoCamera.left = -h * aspect / 2;
            orthoCamera.right = h * aspect / 2;
            orthoCamera.top = h / 2;
            orthoCamera.bottom = -h / 2;
            orthoCamera.zoom = 1;
            orthoCamera.updateProjectionMatrix();
        }
    orbit.update();
}

// --- NEW SCENE LOGIC ---
function newScene() {
    if(confirm("Start new scene? All unsaved work will be lost.")) {
        objects.forEach(o => { scene.remove(o); disposeHierarchy(o); });
        objects = [];
        undoStack.flat().forEach(o => disposeHierarchy(o));
        redoStack.flat().forEach(o => disposeHierarchy(o));
        undoStack = [];
        redoStack = [];
        deselectAll();
        clearRuler();
        if(rulerActive) handleRulerButton();
        if(isOrtho) toggleCamera();
        camera.position.set(25, -25, 25);
        orbit.target.set(0, 0, 0);
        camera.lookAt(0, 0, 0);
        orbit.update();
        document.getElementById('project-name').value = "UNTITLED_PROJECT";
        document.getElementById('status-text').innerText = "New Scene Created";
        
        localStorage.removeItem('jscad_autosave');
        localStorage.removeItem('jscad_project_name');
    }
}

// --- UNDO ENGINE ---
function captureState() {
    return objects.map(o => {
        const c = o.clone();
        c.uuid = o.uuid; // Preserve UUID for selection restoration
        c.traverse(child => { if(child.isMesh) child.material = child.material.clone(); });
        return c;
    });
}

function pushToUndo() {
    undoStack.push(captureState());
    if (undoStack.length > 20) {
        const dropped = undoStack.shift();
        dropped.forEach(o => disposeHierarchy(o));
    }
    redoStack.flat().forEach(o => disposeHierarchy(o));
    redoStack = [];
}

function undo() {
    if (undoStack.length === 0) return;
    const selectedUUIDs = selection.map(o => o.uuid);
    
    redoStack.push(captureState());
    const stateData = undoStack.pop();
    objects.forEach(o => scene.remove(o));
    objects = [];
    stateData.forEach(o => {
        scene.add(o);
        objects.push(o);
        updateObjectVisuals(o);
    });
    deselectAll();
    
    const objectsToReselect = objects.filter(o => selectedUUIDs.includes(o.uuid));
    objectsToReselect.forEach(o => selectObject(o, true));
    
    document.getElementById('status-text').innerText = "Undo performed";
}

function redo() {
    if (redoStack.length === 0) return;
    const selectedUUIDs = selection.map(o => o.uuid);
    
    undoStack.push(captureState());
    const stateData = redoStack.pop();
    objects.forEach(o => scene.remove(o));
    objects = [];
    stateData.forEach(o => {
        scene.add(o);
        objects.push(o);
        updateObjectVisuals(o);
    });
    deselectAll();
    
    const objectsToReselect = objects.filter(o => selectedUUIDs.includes(o.uuid));
    objectsToReselect.forEach(o => selectObject(o, true));
    
    document.getElementById('status-text').innerText = "Redo performed";
}

function toggleRandomColors() {
    useRandomColors = !useRandomColors;
    const btn = document.getElementById('rand-color-toggle');
    const picker = document.getElementById('objColor');
    btn.innerText = `Random Colors: ${useRandomColors ? 'ON' : 'OFF'}`;
    btn.classList.toggle('active');
    if(useRandomColors) picker.classList.add('disabled'); else picker.classList.remove('disabled');
    objects.forEach(obj => updateObjectVisuals(obj));
}

function updateObjectVisuals(obj) {
    obj.traverse(child => {
        if (child.isMesh) {
            if (useRandomColors) {
                if (!child.userData.randomColor) child.userData.randomColor = generateRandomColor();
                child.material.color.setHex(child.userData.randomColor);
            } else {
                const trueColor = child.userData.trueColor || 0xcccccc;
                child.material.color.setHex(trueColor);
            }
            const op = child.userData.opacity !== undefined ? child.userData.opacity : 1;
            child.material.opacity = op;
            child.material.transparent = (op < 1);
        }
    });
}

function mirrorSelected(axis) {
    if (selection.length === 0) return;
    pushToUndo();
    const doCopy = document.getElementById('mirror-copy').checked;
    if (doCopy) {
        const newClones = [];
        selection.forEach(obj => { 
            const clone = obj.clone();
            clone.name = (obj.name || "Object") + " Mirrored";
            clone.position[axis] *= -1; clone.scale[axis] *= -1; 
            clone.traverse(child => { if(child.isMesh) { child.userData.randomColor = generateRandomColor(); child.material = child.material.clone(); } });
            scene.add(clone); objects.push(clone); newClones.push(clone);
        });
        deselectAll();
        newClones.forEach(c => selectObject(c, true));
    } else {
        selection.forEach(obj => { obj.position[axis] *= -1; obj.scale[axis] *= -1; });
    }
    objects.forEach(o => updateObjectVisuals(o));
    if(selection.length > 0) updateInspectorUI(selection[selection.length - 1]);
}

function handleSTLImport(e) {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
        pushToUndo();
        const loader = new STLLoader();
        const geo = loader.parse(ev.target.result);
        geo.center();
        const mat = new THREE.MeshPhysicalMaterial({ color: 0xcccccc, roughness: 0.4, metalness: 0.2, transmission: 0, ior: 1.5, thickness: 0, wireframe: isWireframe, side: THREE.DoubleSide });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(0, 0, 1);
        mesh.userData.trueColor = 0xcccccc;
        mesh.userData.opacity = 1;
        mesh.userData.randomColor = generateRandomColor();
        if (useRandomColors) mesh.material.color.setHex(mesh.userData.randomColor);
        mesh.name = file.name.replace('.stl', '');
        
        // Auto-scale huge STL files down so they don't break the camera
        const size = getLocalSize(mesh);
        const maxDim = Math.max(size.x, size.y, size.z);
        if (maxDim > 50) mesh.scale.setScalar(20 / maxDim);
        
        scene.add(mesh); objects.push(mesh); selectObject(mesh, false);
        e.target.value = ''; // Reset input
    };
    reader.readAsArrayBuffer(file);
}

function handleSVGImport(e) {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
        pushToUndo();
        const loader = new SVGLoader();
        const svgData = loader.parse(ev.target.result);
        const paths = svgData.paths;
        const group = new THREE.Group();
        const mat = new THREE.MeshPhysicalMaterial({ color: 0xcccccc, roughness: 0.4, metalness: 0.2, transmission: 0, ior: 1.5, thickness: 0, wireframe: isWireframe, side: THREE.DoubleSide });

        for ( let i = 0; i < paths.length; i ++ ) {
            const path = paths[ i ];
            const shapes = SVGLoader.createShapes( path );
            for ( let j = 0; j < shapes.length; j ++ ) {
                const shape = shapes[ j ];
                const geo = new THREE.ExtrudeGeometry( shape, {
                    depth: 5, bevelEnabled: true, bevelSegments: 3, steps: 1, bevelSize: 0.2, bevelThickness: 0.2
                });
                geo.center();
                const mesh = new THREE.Mesh( geo, mat.clone() );
                mesh.userData.trueColor = 0xcccccc;
                mesh.userData.opacity = 1;
                mesh.userData.randomColor = generateRandomColor();
                if (useRandomColors) mesh.material.color.setHex(mesh.userData.randomColor);
                group.add( mesh );
            }
        }
        
        // Center the entire SVG group perfectly
        const box = new THREE.Box3().setFromObject(group);
        const center = new THREE.Vector3();
        box.getCenter(center);
        group.children.forEach(c => c.position.sub(center));
        
        group.scale.setScalar(0.2); // SVG scale is usually huge
        group.rotation.x = Math.PI; // SVGs draw upside down by default
        
        // If the SVG was just one solid path, extract it from the group for easier modeling
        if(group.children.length === 1) {
            const mesh = group.children[0];
            mesh.scale.setScalar(0.2);
            mesh.rotation.x = Math.PI;
            mesh.position.set(0, 0, 1);
            mesh.name = file.name.replace('.svg', '');
            scene.add(mesh); objects.push(mesh); selectObject(mesh, false);
        } else {
            group.position.set(0, 0, 1);
            group.name = file.name.replace('.svg', '');
            scene.add(group); 
            objects.push(group);
            selectObject(group, false);
        }
        e.target.value = '';
    };
    reader.readAsText(file);
}

function createShape(type) {
    if(!type) return;
    if(type === 'bevelModal') {
        document.getElementById('bevel-modal').classList.remove('hidden');
        return;
    }

    if (type === 'text') {
        document.getElementById('text-modal').classList.remove('hidden');
        return;
    }

    pushToUndo();
    let geo;
    if(type === 'box') geo = new THREE.BoxGeometry(2, 2, 2);
    else if(type === 'sphere') geo = new THREE.SphereGeometry(1, 32, 32);
    else if(type === 'cylinder') geo = new THREE.CylinderGeometry(1, 1, 2, 32);
    else if(type === 'cone') geo = new THREE.ConeGeometry(1, 2, 32);
    else if(type === 'torus') geo = new THREE.TorusGeometry(1, 0.4, 16, 48);
    else if(type === 'knot') geo = new THREE.TorusKnotGeometry(0.8, 0.3, 100, 16);
    else if(type === 'plane') geo = new THREE.PlaneGeometry(5, 5);
    const mat = new THREE.MeshPhysicalMaterial({ color: 0xcccccc, roughness: 0.4, metalness: 0.2, transmission: 0, ior: 1.5, thickness: 0, wireframe: isWireframe, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(geo, mat);
    if(['cylinder','cone','torus'].includes(type)) mesh.rotation.x = Math.PI / 2;
    mesh.position.set(0, 0, 1); 
    mesh.userData.trueColor = 0xcccccc;
    mesh.userData.opacity = 1;
    mesh.userData.randomColor = generateRandomColor();
    if (useRandomColors) mesh.material.color.setHex(mesh.userData.randomColor);
    mesh.name = type.charAt(0).toUpperCase() + type.slice(1) + " " + (objects.length + 1);
    scene.add(mesh); objects.push(mesh); selectObject(mesh, false);
}

function confirmTextShape() {
    const userText = document.getElementById('text-input').value || "Text";
    const fontName = document.getElementById('text-font').value;
    const fontStyle = document.getElementById('text-style').value;
    const size = parseFloat(document.getElementById('text-size').value);
    const depth = parseFloat(document.getElementById('text-depth').value);

    closeTextModal();
    pushToUndo();

    // Let the user know the font is downloading
    const statusEl = document.getElementById('status-text');
    statusEl.innerText = "Downloading Font...";

    // Build the dynamic URL for the selected font configuration
    let fontPath = `${fontName}_${fontStyle}.typeface.json`;
    if (fontName.startsWith('droid_')) {
        fontPath = `droid/${fontPath}`;
    }
    const fontUrl = `https://cdn.jsdelivr.net/gh/mrdoob/three.js@r160/examples/fonts/${fontPath}`;

    const loader = new FontLoader();
    loader.load(fontUrl, function (font) {
        const textGeo = new TextGeometry(userText, {
            font: font, size: size, height: depth, curveSegments: 12,
            bevelEnabled: true, bevelThickness: size * 0.05, bevelSize: size * 0.02, bevelSegments: 3
        });
        textGeo.center();
        
        // Convert to pure BufferGeometry so it serializes correctly on Undo
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', textGeo.getAttribute('position'));
        geo.setAttribute('normal', textGeo.getAttribute('normal'));
        if (textGeo.getAttribute('uv')) geo.setAttribute('uv', textGeo.getAttribute('uv'));
        if (textGeo.getIndex()) geo.setIndex(textGeo.getIndex());
        
        // Force bounding calculations so frustum culling and selection helpers work immediately
        geo.computeBoundingBox();
        geo.computeBoundingSphere();
        
        const mat = new THREE.MeshPhysicalMaterial({ color: 0xcccccc, roughness: 0.4, metalness: 0.2, transmission: 0, ior: 1.5, thickness: 0, wireframe: isWireframe, side: THREE.DoubleSide });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(0, 0, 0);
        mesh.userData.trueColor = 0xcccccc;
        mesh.userData.opacity = 1;
        mesh.userData.randomColor = generateRandomColor();
        if (useRandomColors) mesh.material.color.setHex(mesh.userData.randomColor);
        mesh.name = "Text: " + userText;
        scene.add(mesh); objects.push(mesh); selectObject(mesh, false);
        
        statusEl.innerText = "Select objects...";
    }, undefined, function (error) {
        alert("Error loading font. Some styles (like Bold) might not be available for all fonts.");
        undoStack.pop(); // Revert undo push if font fetch fails
        statusEl.innerText = "Select objects...";
    });
}

function confirmBevelShape() {
    const type = document.getElementById('bevel-type').value;
    const size = parseFloat(document.getElementById('bevel-size').value);
    const segments = parseInt(document.getElementById('bevel-segments').value);
    
    closeBevelModal();
    pushToUndo();
    
    let geo;
    let name = "Beveled ";
    if (type === 'box') {
        geo = new RoundedBoxGeometry(2, 2, 2, segments, size);
        name += "Cube";
    } else if (type === 'cylinder') {
        const s = new THREE.Shape();
        const baseRadius = Math.max(0.001, 1 - size); // Prevent math collapse if size is too big
        s.absarc(0, 0, baseRadius, 0, Math.PI * 2, false);
        const depth = Math.max(0.001, 2 - (size * 2));
        geo = new THREE.ExtrudeGeometry(s, {
            depth: depth, bevelEnabled: true, bevelSegments: segments, 
            steps: 1, bevelSize: size, bevelThickness: size, curveSegments: 32
        });
        geo.center();
        // Use LatheGeometry for a mathematically perfect seamless cylinder
        const points = [];
        const radius = 1;
        const halfHeight = 1;
        const actualSize = Math.min(size, Math.min(radius, halfHeight)); // Protect against overlapping bevels

        points.push(new THREE.Vector2(0, halfHeight));
        points.push(new THREE.Vector2(radius - actualSize, halfHeight));
        
        for (let i = 1; i <= segments; i++) {
            const angle = (Math.PI / 2) * (1 - i / segments);
            points.push(new THREE.Vector2(
                (radius - actualSize) + Math.cos(angle) * actualSize,
                (halfHeight - actualSize) + Math.sin(angle) * actualSize
            ));
        }
        for (let i = 0; i <= segments; i++) {
            const angle = (Math.PI / 2) * (-i / segments);
            points.push(new THREE.Vector2(
                (radius - actualSize) + Math.cos(angle) * actualSize,
                (-halfHeight + actualSize) + Math.sin(angle) * actualSize
            ));
        }
        points.push(new THREE.Vector2(0, -halfHeight));
        
        geo = new THREE.LatheGeometry(points, 32);
        geo.rotateX(Math.PI / 2); // Align it to the Z axis like the other cylinders
        name += "Cylinder";
    }
    
    const mat = new THREE.MeshPhysicalMaterial({ color: 0xcccccc, roughness: 0.4, metalness: 0.2, transmission: 0, ior: 1.5, thickness: 0, wireframe: isWireframe, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(geo, mat);
    
    mesh.position.set(0, 0, 1); 
    mesh.userData.trueColor = 0xcccccc;
    mesh.userData.opacity = 1;
    mesh.userData.randomColor = generateRandomColor();
    if (useRandomColors) mesh.material.color.setHex(mesh.userData.randomColor);
    mesh.name = name + " " + (objects.length + 1);
    scene.add(mesh); objects.push(mesh); selectObject(mesh, false);
}

function performBoolean(op) {
    if (selection.length < 2) return;
    const meshA = selection[0], meshB = selection[1];
    if (!meshA.isMesh || !meshB.isMesh) return alert("Ungroup first.");
    pushToUndo();
    const brushA = new Brush(meshA.geometry, meshA.material); brushA.position.copy(meshA.position); brushA.rotation.copy(meshA.rotation); brushA.scale.copy(meshA.scale); brushA.updateMatrixWorld();
    const brushB = new Brush(meshB.geometry, meshB.material); brushB.position.copy(meshB.position); brushB.rotation.copy(meshB.rotation); brushB.scale.copy(meshB.scale); brushB.updateMatrixWorld();
    const res = csgEvaluator.evaluate(brushA, brushB, op === 'subtract' ? SUBTRACTION : op === 'union' ? ADDITION : INTERSECTION);
    const mesh = new THREE.Mesh(res.geometry, new THREE.MeshPhysicalMaterial({ color: meshA.userData.trueColor || 0xcccccc, roughness: 0.4, metalness: 0.2, transmission: 0, ior: 1.5, thickness: 0, wireframe: isWireframe }));
    mesh.userData.trueColor = meshA.userData.trueColor || 0xcccccc;
    mesh.userData.opacity = meshA.userData.opacity || 1;
    mesh.userData.randomColor = generateRandomColor();
    updateObjectVisuals(mesh);
    mesh.position.copy(res.position); mesh.rotation.copy(res.rotation); mesh.scale.copy(res.scale);
    deselectAll(); scene.remove(meshA); scene.remove(meshB);
    objects = objects.filter(o => o !== meshA && o !== meshB);
    mesh.name = op.charAt(0).toUpperCase() + op.slice(1) + " Result";
    scene.add(mesh); objects.push(mesh); selectObject(mesh, false);
}

function selectObject(obj, multi) {
    if (!multi) deselectAll(true);
    if (!selection.includes(obj)) { 
        selection.push(obj); 
        const helper = new THREE.BoxHelper(obj, 0xffa500); // CAD Orange
        scene.add(helper);
        selectionHelpers.push({ obj: obj, helper: helper });
    }
    transform.attach(obj); updateInspectorUI(obj); 
    document.getElementById('inspector').classList.remove('hidden');
    updateOutliner();
}

function deselectAll(skipUpdate = false) { 
    selectionHelpers.forEach(h => scene.remove(h.helper));
    selectionHelpers = [];
    selection = []; 
    transform.detach(); 
    document.getElementById('inspector').classList.add('hidden');
    if (!skipUpdate) updateOutliner();
}

function onPointerUp(event) { 
    if (isMarquee) {
        isMarquee = false;
        marqueeElem.style.display = 'none';
        orbit.enabled = true;
        
        const minX = Math.min(marqueeStart.x, event.clientX);
        const maxX = Math.max(marqueeStart.x, event.clientX);
        const minY = Math.min(marqueeStart.y, event.clientY);
        const maxY = Math.max(marqueeStart.y, event.clientY);
        
        if (maxX - minX > 5 || maxY - minY > 5) {
            objects.forEach(obj => {
                const box = new THREE.Box3().setFromObject(obj);
                const corners = [
                    new THREE.Vector3(box.min.x, box.min.y, box.min.z),
                    new THREE.Vector3(box.min.x, box.min.y, box.max.z),
                    new THREE.Vector3(box.min.x, box.max.y, box.min.z),
                    new THREE.Vector3(box.min.x, box.max.y, box.max.z),
                    new THREE.Vector3(box.max.x, box.min.y, box.min.z),
                    new THREE.Vector3(box.max.x, box.min.y, box.max.z),
                    new THREE.Vector3(box.max.x, box.max.y, box.min.z),
                    new THREE.Vector3(box.max.x, box.max.y, box.max.z)
                ];
                let inside = false;
                for (let c of corners) {
                    c.project(camera);
                    const sx = (c.x * 0.5 + 0.5) * window.innerWidth;
                    const sy = -(c.y * 0.5 - 0.5) * window.innerHeight;
                    if (c.z < 1 && sx >= minX && sx <= maxX && sy >= minY && sy <= maxY) { inside = true; break; }
                }
                if (inside) selectObject(obj, true);
            });
            return;
        }
    }

    // If the mouse moved more than 5 pixels, it was a drag (rotation/pan), not a click.
    if (pointerDownPosition.distanceTo(new THREE.Vector2(event.clientX, event.clientY)) > 5) return; 

    if (transform.axis !== null || event.target.closest('.panel') || event.target.tagName === 'SELECT' || event.target.tagName === 'INPUT') return; 
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1; mouse.y = -(event.clientY / window.innerHeight) * 2 + 1; 
    
    // RULER LOGIC INTERCEPT
    if (rulerActive) {
        handleRulerClick();
        return;
    }

    if (dropSurfaceActive) {
        if (pointerDownPosition.distanceTo(new THREE.Vector2(event.clientX, event.clientY)) > 5) return;
        raycaster.setFromCamera(mouse, camera);
        
        // Don't raycast against currently selected objects
        const targetObjects = objects.filter(o => {
            let isSelected = false;
            o.traverseAncestors(p => { if (selection.includes(p)) isSelected = true; });
            return !selection.includes(o) && !isSelected;
        });

        const intersects = raycaster.intersectObjects(targetObjects, true);
        if (intersects.length > 0) {
            const intersect = intersects[0];
            performDropToSurface(intersect.point, intersect.face.normal, intersect.object);
            handleDropButton(); // Turn tool off
            document.getElementById('status-text').innerText = "Snapped to face!";
        }
        return;
    }

    raycaster.setFromCamera(mouse, camera); const intersects = raycaster.intersectObjects(objects, true); 
    if (intersects.length > 0) { 
        let target = intersects[0].object; 
        while(target.parent && target.parent !== scene && !objects.includes(target)) target = target.parent; 
        selectObject(target, event.shiftKey); 
    } else if (!transform.dragging) deselectAll(); 
}

function setToolMode(m) { 
    // 1. Disable "Measuring Mode" (active clicking)
    rulerActive = false;
    dropSurfaceActive = false;
    const btn = document.getElementById('tool-ruler');
    btn.classList.remove('active-ruler-mode');
    document.getElementById('tool-drop').classList.remove('active-tool');
    
    // 2. But if a measurement EXISTS, allow button to show "Visible" state
    if (rulerPoints.length > 0) {
        btn.classList.add('active-ruler-visible');
    } else {
        btn.classList.remove('active-ruler-visible');
    }

    document.getElementById('status-text').innerText = "Select objects...";
    
    transform.setMode(m); 
    document.querySelectorAll('.active-tool').forEach(b => b.classList.remove('active-tool')); 
    document.getElementById(`tool-${m==='translate'?'move':m}`).classList.add('active-tool'); 

    // Scale forces Local space to prevent 3D shearing. Update UI to reflect this!
    const spaceBtn = document.getElementById('space-toggle');
    if (m === 'scale') {
        spaceBtn.innerText = "Space: LOCAL";
        spaceBtn.style.opacity = "0.5";
        spaceBtn.style.pointerEvents = "none";
    } else {
        spaceBtn.innerText = `Space: ${currentSpace.toUpperCase()}`;
        spaceBtn.style.opacity = "1";
        spaceBtn.style.pointerEvents = "auto";
        if (currentSpace === 'local') spaceBtn.classList.add('active-tool');
        else spaceBtn.classList.remove('active-tool');
    }
}

function forceMaterialUpgrade(obj) {
    obj.traverse(child => {
        if (child.isMesh && child.material) {
            const oldMat = child.material;
            child.material = new THREE.MeshPhysicalMaterial({
                color: oldMat.color || new THREE.Color(0xcccccc),
                roughness: oldMat.roughness !== undefined ? oldMat.roughness : 0.4,
                metalness: oldMat.metalness !== undefined ? oldMat.metalness : 0.2,
                transmission: oldMat.transmission || 0,
                ior: oldMat.ior || 1.5,
                thickness: oldMat.thickness || 0,
                wireframe: oldMat.wireframe || false,
                side: THREE.DoubleSide,
                transparent: oldMat.transparent || false,
                opacity: oldMat.opacity !== undefined ? oldMat.opacity : 1
            });
            oldMat.dispose();
        }
    });
}

function loadProject(e) { const file = e.target.files[0]; if(!file) return; const reader = new FileReader(); reader.onload = (ev) => { const data = JSON.parse(ev.target.result); objects.forEach(o => scene.remove(o)); objects = []; deselectAll(true); const loader = new THREE.ObjectLoader(); data.objects.forEach(json => { const o = loader.parse(json); forceMaterialUpgrade(o); scene.add(o); objects.push(o); updateObjectVisuals(o); }); updateOutliner(); }; reader.readAsText(file); }
function groupSelected() { if (selection.length < 2) return; pushToUndo(); const group = new THREE.Group(); group.name = "Group " + (objects.length + 1); scene.add(group); selection.forEach(obj => { objects = objects.filter(o => o !== obj); group.add(obj); }); objects.push(group); deselectAll(true); selectObject(group, false); }
function ungroupSelected() { if (selection.length !== 1 || !selection[0].isGroup) return; pushToUndo(); const group = selection[0]; [...group.children].forEach(child => { scene.attach(child); objects.push(child); }); scene.remove(group); objects = objects.filter(o => o !== group); deselectAll(); }
function cloneSelected() { pushToUndo(); const clones = []; selection.forEach(obj => { const c = obj.clone(); c.name = (obj.name || "Object") + " Copy"; c.position.x += 0.5; c.traverse(child => { if(child.isMesh) { child.userData.randomColor = generateRandomColor(); child.material = child.material.clone(); } }); if(useRandomColors) updateObjectVisuals(c); scene.add(c); objects.push(c); clones.push(c); }); deselectAll(true); clones.forEach(c => selectObject(c, true)); }
function toggleSnap() { isSnapping = !isSnapping; document.getElementById('snap-toggle').innerText = `Grid Snap: ${isSnapping?'ON':'OFF'}`; document.getElementById('snap-toggle').classList.toggle('active'); updateSnapValue(); }
function toggleVertexSnap() { isVertexSnapping = !isVertexSnapping; document.getElementById('vertex-snap-toggle').innerText = `Vertex Snap: ${isVertexSnapping ? 'ON' : 'OFF'}`; document.getElementById('vertex-snap-toggle').classList.toggle('active'); }
function updateSnapValue() { const displayVal = parseFloat(document.getElementById('snap-val').value); const v = fromDisplay(displayVal, currentUnit); transform.translationSnap = isSnapping?v:null; transform.rotationSnap = isSnapping?THREE.MathUtils.degToRad(15):null; transform.scaleSnap = isSnapping?0.1:null; }
function setUnit(u) { 
    currentUnit = u; 
    document.querySelectorAll('.unit-btn').forEach(b => b.classList.remove('active-unit')); 
    document.getElementById(`unit-${u}`).classList.add('active-unit'); 
    if(selection.length > 0) updateInspectorUI(selection[selection.length-1]); 
    document.querySelectorAll('.unit-text').forEach(el=>el.innerText=u); 
    updateSnapValue(); 
    
    // Dynamic Grid Update
    const oldGrid = scene.getObjectByName('FloorGrid');
    if (oldGrid) { scene.remove(oldGrid); oldGrid.geometry.dispose(); oldGrid.material.dispose(); }
    const size = u === 'in' ? 254 : 256; // 10 inches or 256 mm
    const divisions = u === 'in' ? 10 : 256; // 1-inch squares or 1-mm squares
    const newGrid = new THREE.GridHelper(size, divisions, 0x444444, 0x383838);
    newGrid.rotation.x = Math.PI / 2;
    newGrid.name = 'FloorGrid';
    scene.add(newGrid);
}

function disposeHierarchy(node) {
    node.traverse(child => {
        if (child.geometry) child.geometry.dispose();
        if (child.material) {
            if (Array.isArray(child.material)) child.material.forEach(m => m.dispose());
            else child.material.dispose();
        }
    });
}

function deleteObject() { 
    if(selection.length > 0) pushToUndo(); 
    selection.forEach(obj => { scene.remove(obj); disposeHierarchy(obj); objects = objects.filter(o => o !== obj); }); 
    deselectAll(); 
}

function performDropToSurface(point, localNormal, targetMesh) {
    pushToUndo();
    
    // Convert local face normal to world space
    const worldNormal = localNormal.clone().transformDirection(targetMesh.matrixWorld).normalize();
    
    selection.forEach(obj => {
        // 1. Rotate to align the object's current Z axis with the target normal
        const currentZ = new THREE.Vector3(0, 0, 1).applyQuaternion(obj.quaternion).normalize();
        const alignQuat = new THREE.Quaternion().setFromUnitVectors(currentZ, worldNormal);
        obj.quaternion.premultiply(alignQuat);
        
        // 2. Snap position exactly to the clicked point first
        obj.position.copy(point);
        obj.updateMatrixWorld(true);
        
        // 3. Iterate all vertices to find how far the object sinks into the surface
        let minProj = Infinity;
        obj.traverse(child => {
            if (child.isMesh && child.geometry) {
                const pos = child.geometry.attributes.position;
                const wMat = child.matrixWorld;
                for (let i = 0; i < pos.count; i++) {
                    const v = new THREE.Vector3().fromBufferAttribute(pos, i).applyMatrix4(wMat);
                    const offsetV = v.clone().sub(point);
                    const proj = offsetV.dot(worldNormal);
                    if (proj < minProj) minProj = proj;
                }
            }
        });
        
        // 4. Shift the object up along the normal so the lowest vertex sits perfectly flush
        if (minProj !== Infinity) {
            obj.position.add(worldNormal.clone().multiplyScalar(-minProj));
        }
    });
    updateInspectorUI(selection[selection.length - 1]);
}

function toggleTheme() {
    isLightMode = !isLightMode;
    document.getElementById('theme-toggle').innerText = `Theme: ${isLightMode ? 'LIGHT' : 'DARK'}`;
    document.getElementById('theme-toggle').classList.toggle('active');
    scene.background.setHex(isLightMode ? 0xeeeeee : 0x303030);
    
    // Instantly redraw the grid in a lighter color
    const oldGrid = scene.getObjectByName('FloorGrid');
    if (oldGrid) { scene.remove(oldGrid); oldGrid.geometry.dispose(); oldGrid.material.dispose(); }
    const size = currentUnit === 'in' ? 254 : 256; 
    const divisions = currentUnit === 'in' ? 10 : 256;
    const newGrid = new THREE.GridHelper(size, divisions, isLightMode ? 0x888888 : 0x444444, isLightMode ? 0xdddddd : 0x383838);
    newGrid.rotation.x = Math.PI / 2;
    newGrid.name = 'FloorGrid';
    scene.add(newGrid);
}

function updateLighting(val) {
    const intensity = parseFloat(val);
    document.getElementById('light-val').innerText = Math.round(intensity * 100);
    const ambient = scene.getObjectByName('AmbientLight');
    const sun = scene.getObjectByName('SunLight');
    if(ambient) ambient.intensity = 0.6 * intensity;
    if(sun) sun.intensity = 1.0 * intensity;
}

function toggleDimensions() { showDimensions = !showDimensions; document.getElementById('dim-toggle').innerText = `Dimensions: ${showDimensions ? 'ON' : 'OFF'}`; document.getElementById('dim-toggle').classList.toggle('active'); }

function toggleWireframe() { isWireframe = !isWireframe; document.getElementById('wire-toggle').classList.toggle('active'); scene.traverse(obj => { if(obj.isMesh) obj.material.wireframe = isWireframe; }); }

function toggleBuildPlate() { 
    isBuildPlate = !isBuildPlate; 
    buildPlate.visible = isBuildPlate; 
    document.getElementById('build-plate-toggle').innerText = `Build Plate: ${isBuildPlate ? 'ON' : 'OFF'}`; 
    document.getElementById('build-plate-toggle').classList.toggle('active'); 
}


function updateOutliner() {
    const list = document.getElementById('outliner-list');
    if (!list) return;
    list.innerHTML = '';
    
    list.ondragover = (e) => { e.preventDefault(); e.stopPropagation(); };
    list.ondrop = (e) => { e.stopPropagation(); handleDrop(e, 'root'); };

    if (objects.length === 0) {
        list.innerHTML = '<div class="status-msg" style="margin:0; padding:10px;">Scene is empty</div>';
        return;
    }

    function buildTree(parentArray, container, indent) {
        parentArray.forEach((obj, index) => {
            const item = document.createElement('div');
            item.className = 'outliner-item' + (selection.includes(obj) ? ' active' : '');
            item.draggable = true;
            item.style.paddingLeft = `${indent}px`;
            
            item.ondragstart = (e) => { e.dataTransfer.setData('text/plain', obj.uuid); e.stopPropagation(); };
            item.ondragover = (e) => { e.preventDefault(); e.stopPropagation(); item.classList.add('drag-over'); };
            item.ondragleave = (e) => { e.preventDefault(); e.stopPropagation(); item.classList.remove('drag-over'); };
            item.ondrop = (e) => { e.preventDefault(); e.stopPropagation(); item.classList.remove('drag-over'); handleDrop(e, obj); };
            item.onclick = (e) => { e.stopPropagation(); selectObject(obj, e.shiftKey); };

            if (obj.isGroup) {
                const toggle = document.createElement('span');
                toggle.innerText = obj.userData.outlinerCollapsed ? "▶ " : "▼ ";
                toggle.style.cursor = "pointer";
                toggle.style.pointerEvents = "auto";
                toggle.style.display = "inline-block";
                toggle.style.width = "15px";
                toggle.style.fontSize = "0.6rem";
                toggle.onclick = (e) => {
                    e.stopPropagation();
                    obj.userData.outlinerCollapsed = !obj.userData.outlinerCollapsed;
                    updateOutliner();
                };
                item.appendChild(toggle);
            } else {
                const spacer = document.createElement('span');
                spacer.style.display = "inline-block";
                spacer.style.width = "15px";
                item.appendChild(spacer);
            }

            const text = document.createElement('span');
            text.innerText = (obj.isGroup ? "📁 " : "🧊 ") + (obj.name || `Object ${index + 1}`);
            text.style.pointerEvents = "none";
            item.appendChild(text);
            container.appendChild(item);

            if (obj.isGroup && obj.children.length > 0) {
                if (!obj.userData.outlinerCollapsed) {
                    buildTree(obj.children.filter(c => c.isMesh || c.isGroup), container, indent + 15);
                }
            }
        });
    }
    buildTree(objects, list, 10);
}

function handleDrop(e, target) {
    const draggedUUID = e.dataTransfer.getData('text/plain');
    if (!draggedUUID) return;
    
    let draggedObj = null;
    scene.traverse(c => { if(c.uuid === draggedUUID) draggedObj = c; });
    if (!draggedObj) return;

    if (target !== 'root') {
        let isChild = false;
        target.traverseAncestors(p => { if (p === draggedObj) isChild = true; });
        if (isChild || target === draggedObj) return;
    }

    pushToUndo();
    objects = objects.filter(o => o !== draggedObj);

    if (target === 'root') {
        scene.attach(draggedObj);
        objects.push(draggedObj);
    } else if (target.isGroup) {
        target.attach(draggedObj);
        target.userData.outlinerCollapsed = false; // Auto-expand when dropped into
    } else {
        target.parent.attach(draggedObj);
        if (target.parent.isGroup) target.parent.userData.outlinerCollapsed = false;
        if (target.parent === scene) objects.push(draggedObj);
    }
    updateOutliner();
}

function alignObjects(axis, type) {
    if (selection.length < 2) return alert("Select at least 2 objects to align.");
    pushToUndo();
    
    const keyObject = selection[selection.length - 1];
    const keyBox = new THREE.Box3().setFromObject(keyObject);
    let targetVal = 0;
    
    if (type === 'min') targetVal = keyBox.min[axis];
    else if (type === 'max') targetVal = keyBox.max[axis];
    else targetVal = (keyBox.min[axis] + keyBox.max[axis]) / 2;

    selection.forEach(obj => {
        if (obj === keyObject) return;
        const objBox = new THREE.Box3().setFromObject(obj);
        let objCenter = (objBox.min[axis] + objBox.max[axis]) / 2;
        
        let offset = 0;
        if (type === 'min') offset = targetVal - objBox.min[axis];
        else if (type === 'max') offset = targetVal - objBox.max[axis];
        else offset = targetVal - objCenter;

        obj.position[axis] += offset;
    });
    
    updateInspectorUI(selection[selection.length - 1]);
    document.getElementById('status-text').innerText = `Aligned ${axis.toUpperCase()} to ${type}`;
}

function performArray() {
    if (selection.length === 0) return alert("Select an object to array.");
    const type = document.getElementById('array-type').value;
    const count = parseInt(document.getElementById('array-count').value);
    if (count < 2) return;

    pushToUndo();
    const target = selection[selection.length - 1];
    const newClones = [];

    const box = new THREE.Box3().setFromObject(target);
    const size = new THREE.Vector3();
    box.getSize(size);

    const dx = type === 'linear' ? (parseFloat(document.getElementById('array-dx').value) || 0) * size.x : 0;
    const dy = type === 'linear' ? (parseFloat(document.getElementById('array-dy').value) || 0) * size.y : 0;
    const dz = type === 'linear' ? (parseFloat(document.getElementById('array-dz').value) || 0) * size.z : 0;

    const axisStr = type === 'radial' ? document.getElementById('array-axis').value : 'z';
    const totalRad = type === 'radial' ? THREE.MathUtils.degToRad(parseFloat(document.getElementById('array-angle').value) || 360) : 0;
    let axisVec = new THREE.Vector3(axisStr === 'x' ? 1 : 0, axisStr === 'y' ? 1 : 0, axisStr === 'z' ? 1 : 0);

    for (let i = 1; i < count; i++) {
        const clone = target.clone();
        clone.name = (target.name || "Object") + " Array " + i;
        clone.traverse(child => { if(child.isMesh) { child.userData.randomColor = generateRandomColor(); child.material = child.material.clone(); } });
        
        if (type === 'linear') {
            clone.position.add(new THREE.Vector3(dx * i, dy * i, dz * i));
        } else if (type === 'radial') {
            const stepRad = totalRad * (i / count);
            clone.position.applyAxisAngle(axisVec, stepRad);
            clone.rotateOnWorldAxis(axisVec, stepRad);
        }

        if(useRandomColors) updateObjectVisuals(clone);
        if (target.parent === scene) objects.push(clone);
        target.parent.add(clone);
        newClones.push(clone);
    }

    document.getElementById('array-modal').classList.add('hidden');
    deselectAll(true);
    newClones.push(target);
    newClones.forEach(c => selectObject(c, true));
    updateOutliner();
    document.getElementById('status-text').innerText = "Array created";
}

function updateInspectorUI(obj) {
    const safeSet = (id, val) => { if(document.activeElement !== document.getElementById(id)) document.getElementById(id).value = val.toFixed(2); };
    
    // Get accurate local size
    const size = getLocalSize(obj);
    
    document.getElementById('objName').value = obj.name || "Object";
    document.getElementById('dimX').value = formatVal(size.x, currentUnit); 
    document.getElementById('dimY').value = formatVal(size.y, currentUnit); 
    document.getElementById('dimZ').value = formatVal(size.z, currentUnit);
    
    safeSet('posX', toDisplay(obj.position.x, currentUnit)); safeSet('posY', toDisplay(obj.position.y, currentUnit)); safeSet('posZ', toDisplay(obj.position.z, currentUnit));
    safeSet('rotX', toDeg(obj.rotation.x)); safeSet('rotY', toDeg(obj.rotation.y)); safeSet('rotZ', toDeg(obj.rotation.z));
    
    let colorHex = "#cccccc"; let opVal = 1; let matType = "matte";
    obj.traverse(c => { if(c.isMesh) { const sc = c.userData.trueColor || 0xcccccc; colorHex = "#" + new THREE.Color(sc).getHexString(); opVal = c.userData.opacity !== undefined ? c.userData.opacity : 1; matType = c.userData.materialType || "matte"; }});
    document.getElementById('objColor').value = colorHex; document.getElementById('objOpacity').value = opVal; document.getElementById('opacity-val').innerText = Math.round(opVal * 100);
    const matSelect = document.getElementById('objMaterial');
    if (matSelect) matSelect.value = matType;
}

function updateObjectFromUI() {
    if(selection.length === 0) return;
    const obj = selection[selection.length - 1];
    
    // 1. Handle Transformations
    const getVal = (id) => parseFloat(document.getElementById(id).value) || 0;
    obj.position.set(fromDisplay(getVal('posX'), currentUnit), fromDisplay(getVal('posY'), currentUnit), fromDisplay(getVal('posZ'), currentUnit));
    obj.rotation.set(toRad(getVal('rotX')), toRad(getVal('rotY')), toRad(getVal('rotZ')));
    
    // 2. Handle Resizing (Smart Scale)
    const currentSize = getLocalSize(obj);
    if (currentSize.x < 0.001) currentSize.x = 0.001;
    if (currentSize.y < 0.001) currentSize.y = 0.001;
    if (currentSize.z < 0.001) currentSize.z = 0.001;

    // Math.max guarantees the scale never drops to exactly zero and locks the object
    const newW = Math.max(0.001, fromDisplay(parseFloat(document.getElementById('dimX').value) || 0.001, currentUnit));
    const newD = Math.max(0.001, fromDisplay(parseFloat(document.getElementById('dimY').value) || 0.001, currentUnit));
    const newH = Math.max(0.001, fromDisplay(parseFloat(document.getElementById('dimZ').value) || 0.001, currentUnit));
    
    obj.scale.x *= (newW / currentSize.x);
    obj.scale.y *= (newD / currentSize.y);
    obj.scale.z *= (newH / currentSize.z);

    // 3. Handle Visuals
    const pickedColor = document.getElementById('objColor').value;
    const pickedOpacity = parseFloat(document.getElementById('objOpacity').value);
    const pickedMat = document.getElementById('objMaterial') ? document.getElementById('objMaterial').value : 'matte';
    obj.traverse(c => { 
        if(c.isMesh) { 
            c.userData.trueColor = parseInt(pickedColor.replace("#","0x")); 
            c.userData.opacity = pickedOpacity; 
            c.userData.materialType = pickedMat;
            if(!useRandomColors) c.material.color.set(pickedColor); 
            c.material.opacity = pickedOpacity; 
            c.material.transparent = (pickedOpacity < 1 || pickedMat === 'glass'); 
            
            if (pickedMat === 'metal') {
                c.material.roughness = 0.2; c.material.metalness = 0.8; c.material.transmission = 0; c.material.thickness = 0;
            } else if (pickedMat === 'glass') {
                c.material.roughness = 0.05; c.material.metalness = 0.1; c.material.transmission = 0.9; c.material.ior = 1.5; c.material.thickness = 2.0;
            } else { // matte
                c.material.roughness = 0.4; c.material.metalness = 0.2; c.material.transmission = 0; c.material.thickness = 0;
            }
            c.material.needsUpdate = true; // Tell WebGL to recompile the shader to handle the new transmission properties
        } 
    });
    
    document.getElementById('opacity-val').innerText = Math.round(pickedOpacity * 100);
}

function copySelected() {
    if (selection.length === 0) return;
    clipboard = selection.map(obj => {
        const c = obj.clone();
        c.traverse(child => { if(child.isMesh) child.material = child.material.clone(); });
        return c;
    });
    document.getElementById('status-text').innerText = "Copied to clipboard";
}

function pasteCopied() {
    if (clipboard.length === 0) return;
    pushToUndo();
    const pasted = [];
    clipboard.forEach(obj => {
        const c = obj.clone();
        c.name = (obj.name || "Object") + " Pasted";
        c.position.x += 0.5; c.position.y += 0.5;
        c.traverse(child => { if(child.isMesh) { child.userData.randomColor = generateRandomColor(); child.material = child.material.clone(); } });
        if(useRandomColors) updateObjectVisuals(c);
        scene.add(c); objects.push(c); pasted.push(c);
    });
    deselectAll(true);
    pasted.forEach(c => selectObject(c, true));
    document.getElementById('status-text').innerText = "Pasted from clipboard";
}

function toggleCamera() {
    isOrtho = !isOrtho;
    const prevCam = camera;
    camera = isOrtho ? orthoCamera : perspCamera;
    
    if (isOrtho) {
        camera.position.copy(prevCam.position);
        camera.up.copy(prevCam.up);
        camera.lookAt(orbit.target);
        
        const dist = prevCam.position.distanceTo(orbit.target);
        const fov = perspCamera.fov * (Math.PI / 180);
        const h = 2 * dist * Math.tan(fov / 2);
        const aspect = window.innerWidth / window.innerHeight;
        
        orthoCamera.left = -h * aspect / 2;
        orthoCamera.right = h * aspect / 2;
        orthoCamera.top = h / 2;
        orthoCamera.bottom = -h / 2;
        orthoCamera.zoom = 1;
        orthoCamera.updateProjectionMatrix();
    } else {
        const dist = prevCam.position.distanceTo(orbit.target);
        const newDist = dist / prevCam.zoom;
        const dir = prevCam.position.clone().sub(orbit.target).normalize();
        
        camera.position.copy(orbit.target).add(dir.multiplyScalar(newDist));
        camera.up.copy(prevCam.up);
        camera.lookAt(orbit.target);
        
        prevCam.zoom = 1;
        prevCam.updateProjectionMatrix();
        camera.updateProjectionMatrix();
    }

    orbit.object = camera;
    transform.camera = camera;
    orbit.update();
    document.getElementById('status-text').innerText = isOrtho ? "Orthographic View" : "Perspective View";
}

function setOrigin(type) {
    if (selection.length === 0) return;
    pushToUndo();
    selection.forEach(obj => {
        if (obj.isGroup) {
            const box = new THREE.Box3().setFromObject(obj);
            const center = new THREE.Vector3();
            box.getCenter(center);
            if (type === 'base') center.z = box.min.z;
            
            const deltaWorld = center.clone().sub(obj.position);
            obj.position.copy(center);
            obj.children.forEach(c => c.position.sub(deltaWorld));
            return;
        }
        if (!obj.geometry) return;
        
        obj.geometry.computeBoundingBox();
        const localCenter = new THREE.Vector3();
        obj.geometry.boundingBox.getCenter(localCenter);
        if (type === 'base') localCenter.z = obj.geometry.boundingBox.min.z;
        
        obj.geometry.translate(-localCenter.x, -localCenter.y, -localCenter.z);
        const deltaWorld = localCenter.applyMatrix4(new THREE.Matrix4().makeRotationFromEuler(obj.rotation).scale(obj.scale));
        obj.position.add(deltaWorld);
    });
    
    transform.detach();
    transform.attach(selection[selection.length - 1]);
    updateInspectorUI(selection[selection.length - 1]);
}

function snapToGrid() {
    if (selection.length === 0) return;
    pushToUndo();
    const displayVal = parseFloat(document.getElementById('snap-val').value) || 1;
    const snap = fromDisplay(displayVal, currentUnit);
    
    selection.forEach(obj => {
        obj.position.x = Math.round(obj.position.x / snap) * snap;
        obj.position.y = Math.round(obj.position.y / snap) * snap;
        obj.position.z = Math.round(obj.position.z / snap) * snap;
    });
    updateInspectorUI(selection[selection.length - 1]);
}

function dropToFloor() {
    if (selection.length === 0) return;
    pushToUndo();
    selection.forEach(obj => {
        const box = new THREE.Box3().setFromObject(obj);
        obj.position.z -= box.min.z;
    });
    updateInspectorUI(selection[selection.length - 1]);
}

function setView(view) {
    const tgt = orbit.target.clone();
    const dist = camera.position.distanceTo(tgt) || 50;
    
    camera.up.set(0, 0, 1); 

    // Add a microscopic offset so the floor grid and axes don't mathematically vanish edge-on
    if (view === 'front') camera.position.set(tgt.x, tgt.y - dist, tgt.z + (dist * 0.001));
    else if (view === 'right') camera.position.set(tgt.x + dist, tgt.y, tgt.z + (dist * 0.001));
    // Use a proportional 1% offset so the angle never collapses to zero when zooming out
    else if (view === 'top') camera.position.set(tgt.x, tgt.y - (dist * 0.01), tgt.z + dist);

    camera.lookAt(tgt);
    camera.updateProjectionMatrix();
    orbit.update(); // Sync controls immediately so zooming doesn't crash
}

function toggleSpace() {
    if (transform.mode === 'scale') return; // Scale must always remain in Local space
    currentSpace = currentSpace === 'world' ? 'local' : 'world';
    transform.setSpace(currentSpace);
    document.getElementById('space-toggle').innerText = `Space: ${currentSpace.toUpperCase()}`;
    document.getElementById('space-toggle').classList.toggle('active-tool', currentSpace === 'local');
}

function onKeyDown(e) { 
    if(['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return; 
    if(e.key === 'm') setToolMode('translate'); 
    if(e.key === 'r') setToolMode('rotate'); 
    if(e.key === 's') setToolMode('scale'); 
    if(e.key === 'q') handleRulerButton();
    if(e.key.toLowerCase() === 't') handleDropButton();
    if(e.key === '0') frameSelected();
    if(e.key === 'g') groupSelected(); 
    if(e.key === '5') toggleCamera(); 
    if(e.key === 'u') ungroupSelected(); 
    if(e.key.toLowerCase() === 'w') toggleSpace();
    
    if(e.shiftKey && e.key.toLowerCase() === 'd') { e.preventDefault(); cloneSelected(); }
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase() === 'c') { e.preventDefault(); copySelected(); }
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase() === 'v') { e.preventDefault(); pasteCopied(); }
    if(e.key === 'Delete' || e.key.toLowerCase() === 'x') deleteObject(); 
    
    if(e.key === '1') setView('front');
    if(e.key === '3') setView('right');
    if(e.key === '7') setView('top');
}
function onWindowResize() { 
    const aspect = window.innerWidth / window.innerHeight;
    perspCamera.aspect = aspect; 
    perspCamera.updateProjectionMatrix(); 
    const h = orthoCamera.top - orthoCamera.bottom || 40;
    orthoCamera.left = -h * aspect / 2;
    orthoCamera.right = h * aspect / 2;
    orthoCamera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight); 
}

function updateDimensionLabels() {
    if (!showDimensions || selection.length === 0) {
        ['dim-x', 'dim-y', 'dim-z'].forEach(id => document.getElementById(id).style.display = 'none');
        return;
    }
    const obj = selection[selection.length - 1];
    const box = new THREE.Box3().setFromObject(obj);
    if (box.isEmpty()) return;

    const size = new THREE.Vector3();
    box.getSize(size);
    
    const ptX = new THREE.Vector3(box.min.x + size.x / 2, box.min.y, box.max.z); // Width edge
    const ptY = new THREE.Vector3(box.max.x, box.min.y + size.y / 2, box.max.z); // Depth edge
    const ptZ = new THREE.Vector3(box.max.x, box.min.y, box.min.z + size.z / 2); // Height edge

    const updateLabel = (id, pt, val) => {
        const el = document.getElementById(id);
        pt.project(camera);
        if (Math.abs(pt.z) > 1) { el.style.display = 'none'; return; }
        const x = (pt.x * .5 + .5) * window.innerWidth;
        const y = (pt.y * -.5 + .5) * window.innerHeight;
        el.style.display = 'block';
        el.style.left = `${x}px`;
        el.style.top = `${y}px`;
        el.innerText = formatVal(val, currentUnit) + (currentUnit === 'mm' ? 'mm' : '"');
    };

    updateLabel('dim-x', ptX, size.x); updateLabel('dim-y', ptY, size.y); updateLabel('dim-z', ptZ, size.z);
}

function animate() { 
    requestAnimationFrame(animate); 
    
    if (viewHelper.animating) {
        viewHelper.update(clock.getDelta());
    } else {
        orbit.update(); 
    }
    
    selectionHelpers.forEach(h => h.helper.update()); 
    
    renderer.clear();
    renderer.setViewport(0, 0, window.innerWidth, window.innerHeight);
    renderer.render(scene, camera); 
    
    renderer.clearDepth();
    viewHelper.render(renderer); // Automatically renders in the bottom-right corner

    updateDimensionLabels();
    if(rulerPoints.length===2) updateRulerLabel(); 
}
