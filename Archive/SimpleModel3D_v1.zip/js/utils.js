import * as THREE from 'three';

export const toDeg = (rad) => rad * (180 / Math.PI);
export const toRad = (deg) => deg * (Math.PI / 180);

export function formatVal(v, currentUnit) { 
    return (currentUnit === 'in' ? v / 25.4 : v).toFixed(currentUnit === 'in' ? 2 : 1); 
}

export function toDisplay(v, currentUnit) { 
    return currentUnit === 'in' ? v / 25.4 : v; 
}

export function fromDisplay(v, currentUnit) { 
    return currentUnit === 'in' ? v * 25.4 : v; 
}

export function generateRandomColor() { 
    return new THREE.Color().setHSL((Math.random() + 0.618) % 1, 0.7, 0.5).getHex(); 
}

export function getLocalSize(obj) {
    const currentRot = obj.rotation.clone();
    obj.rotation.set(0, 0, 0);
    obj.updateMatrixWorld();
    const box = new THREE.Box3().setFromObject(obj);
    const size = new THREE.Vector3();
    box.getSize(size);
    obj.rotation.copy(currentRot);
    obj.updateMatrixWorld();
    return size;
}